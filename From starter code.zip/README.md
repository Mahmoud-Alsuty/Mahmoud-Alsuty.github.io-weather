# Starting weather journal app project
# made on 17/7/2020
getting weather temperatures by zip of city 